<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends MX_Controller {

        public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
                $this->murl = '/modules/'.$this->uri->segment(1).'/';
        }

	public function index()
	{
            echo Modules::run('template/header1','home');
            $this->load->view('index');
	}
        
        
        //BAGIAN PENGUMUMAN
        public function pengumuman()
	{
            echo Modules::run('template/header1','pengumuman');
            $data['kategori'] = $this->Moap->table('master_pengumuman'); 
            $this->load->view('pengumuman',$data);
	}
        
        public function pengumuman_master()
	{
            $data['dat'] = $this->Moap->table('master_pengumuman'); 
            echo Modules::run('template/header1','pengumuman');
            $this->load->view('pengumuman_master',$data);
	}
        
        public function pengumuman_kategori_add()
	{
            $insert = array(
                'kategori' => $this->input->post('kategori'),
                'status' => 1,
            );
            
            $this->Moap->insert('master_pengumuman',$insert);
            redirect('Admin/pengumuman_master');
	}
        
        public function pengumuman_ajax()
	{
            $data = $this->Moap->table('master_pengumuman');
            $dat = array();
            foreach($data as $row){
                $ntv = array();
                $ntv['id'] = $row->id;
                $ntv['kategori'] = $row->kategori;
                $ntv['status'] = $row->status;
                $ntv['aksi'] = "<a href='#' class='btn btn-info'> NON AKTIFKAN </a>";
                $dat[] = $ntv;
            }
            
            echo json_encode($dat);
    }
        
        public function pertemuan()
	{
            echo Modules::run('template/header1','pertemuan');
            $this->load->view('pertemuan');
	}
        
        
        
}
