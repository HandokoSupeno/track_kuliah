

        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Pengaturan Pengumuman</h2>
                    </div>
                </div>              
                 <!-- /. ROW  -->
                  <hr />
                <div class="row">
                    <div class="col-md-12">
                        <a class="btn btn-info" href="<?= site_url('Admin/pengumuman_master') ?>">+ Tambah Master Pengumuman</a>
                    </div>
                </div>
                  <hr />
                  <div class="row">
                        <div class="col-md-1"></div>
                        <div class="col-md-6">
                            <form method="post" action="<?= site_url('Admin/pengumuman_add') ?>">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Kategori</th>
                                            <th>:</th>
                                            <th>
                                                <select name="kategori">
                                                    <?php foreach ($kategori as $row) { ?>
                                                    <option value="<?= $row->id ?>"><?= $row->kategori ?></option>
                                                    <?php } ?>
                                                </select>
                                            </th>
                                        </tr>
                                        <tr>
                                            <th>Judul</th>
                                            <th>:</th>
                                            <th><input type="text" name="kategori" style="width: 100%"/></th>
                                        </tr>
                                        <tr>
                                            <th>Konten</th>
                                            <th>:</th>
                                            <th>
                                                <textarea name="konten"></textarea>
                                            </th>
                                        </tr>
                                        <tr>
                                            <th colspan="3"><center><input type="submit" value="SIMPAN"  /></center></th>
                                        </tr>
                                    </thead>
                                </table>
                            </form>
                        </div>
                    </div>
                  <hr />
                    <h2>KATEGORI PENGUMUMAN TEREGISTER</h2>
                    <div class="row">
                        <div id="data_table" class="col-md-12">
                            <table class="table table-bordered">
                                <thead>
                                   <tr>
                                        <th>ID</th>
                                        <th>KATEGORI</th>
                                        <th>STATUS</th>
                                        <th>AKSI</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                 <!-- /. ROW  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
    <script>
    $(document).ready(function() {
       showTable();        
    } );
    
    function showTable(){
        $.ajax({
                type: "GET",
                url: "<?= site_url('Admin/pengumuman_ajax') ?>",
                async: true,
                success: function(jText) {
                        
                        var listObj = jQuery.parseJSON(jText);
                        
                        var text = '';
                        var i = 0;
                        
                        $.each(listObj, function(i, obj) {
                                text += '<tr>';
                                text += '<td>' + obj.id + '</td>';
                                text += '<td>' + obj.kategori + '</td>';
                                text += '<td>' + obj.status + '</td>';
                                text += '<td>' + obj.aksi + '</td>';
                                text += '</tr>';
                        });
                        //alert("masuk sini = "+text);
                        $('#data_table table > tbody:first').html(text);
                }
        });
    }
</script>