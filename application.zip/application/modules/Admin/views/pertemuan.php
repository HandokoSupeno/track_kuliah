
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h2>PERTEMUAN 1</h2>   
                        <h5>Membahas mengenai world building </h5>
                    </div>
                    <div class="col-md-12">
                        <a href="<?= base_url('assets/pdf/PGC_Bab1_World_Building.pdf') ?>" target="_blank"><img src="<?= base_url("assets/img/pdf.png") ?>" /></a>
                        <h3>REPORT STUDY 1</h3>
                        <p>Deskripsi mengenai video ini</p>
                        <iframe width="907" height="380" src="https://www.youtube.com/embed/8rauD1vxMCw" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
            </div>
             <!-- /. PAGE INNER  -->
         </div>
        