<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends MX_Controller {

        public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
                $this->murl = '/modules/'.$this->uri->segment(1).'/';
        }

	public function index()
	{
            echo Modules::run('template/header1','home');
            $this->load->view('index');
	}
        
        public function pengumuman()
	{
            echo Modules::run('template/header1','pengumuman');
            $this->load->view('pengumuman');
	}
        
        public function pertemuan()
	{
            echo Modules::run('template/header1','pertemuan');
            $this->load->view('pertemuan');
	}
        
        public function test(){
            //$this->load->view('blank');
            //$this->load->view('chart');
            //$this->load->view('form');
            //$this->load->view('table');
            //$this->load->view('table-panel');
            $this->load->view('ui');
        }
        
}
