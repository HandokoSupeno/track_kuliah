<!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <?php $active = ""; ?>
                <ul class="nav" id="main-menu">
                    <li class="text-center">
                        <img src="<?= base_url() ?>assets/img/logo.png" class="user-image img-responsive"/>
                    </li>
                    <li>
                        <?php if($url == 'home')$active = "class='active-menu'"; ?>
                        <a  <?= $active ?> href="<?= site_url('Admin') ?>"><i class="fa fa-dashboard fa-3x"></i> Progress Anda </a>
                        <?php $active = ""; ?>
                    </li>
                     <li>
                         <?php if($url == 'pengumuman')$active = "class='active-menu'"; ?>
                         <a <?= $active ?> href="<?= site_url('Admin/pengumuman') ?>"><i class="fa fa-desktop fa-3x"></i> Pengumuman </a>
                         <?php $active = ""; ?>
                     </li>
                    <li>
                         <?php if($url == 'pertemuan')$active = "class='active-menu'"; ?>
                         <a <?= $active ?> href="<?= site_url('Admin/pertemuan') ?>"><i class="fa fa-edit fa-3x"></i> Pertemuan 1</a>
                         <?php $active = ""; ?>
                     </li>					
                    <li  >
                        <a  href="form.html"><i class="fa fa-edit fa-3x"></i> Pertemuan 2 </a>
                    </li>					
                    <li  >
                        <a  href="form.html"><i class="fa fa-edit fa-3x"></i> Pertemuan 3 </a>
                    </li>					
                    <li  >
                        <a  href="form.html"><i class="fa fa-edit fa-3x"></i> Pertemuan 4 </a>
                    </li>					
                    <li  >
                        <a  href="form.html"><i class="fa fa-edit fa-3x"></i> Pertemuan 5 </a>
                    </li>					
                    <li  >
                        <a  href="form.html"><i class="fa fa-edit fa-3x"></i> Pertemuan 6 </a>
                    </li>					
                    <li  >
                        <a  href="form.html"><i class="fa fa-edit fa-3x"></i> Pertemuan 7 </a>
                    </li>					
                    <li  >
                        <a  href="form.html"><i class="fa fa-edit fa-3x"></i> UTS </a>
                    </li>
                    <li  >
                        <a  href="form.html"><i class="fa fa-edit fa-3x"></i> Pertemuan 8 </a>
                    </li>					
                    <li  >
                        <a  href="form.html"><i class="fa fa-edit fa-3x"></i> Pertemuan 9 </a>
                    </li>					
                    <li  >
                        <a  href="form.html"><i class="fa fa-edit fa-3x"></i> Pertemuan 10 </a>
                    </li>					
                    <li  >
                        <a  href="form.html"><i class="fa fa-edit fa-3x"></i> Pertemuan 11 </a>
                    </li>					
                    <li  >
                        <a  href="form.html"><i class="fa fa-edit fa-3x"></i> Pertemuan 12 </a>
                    </li>					
                    <li  >
                        <a  href="form.html"><i class="fa fa-edit fa-3x"></i> Pertemuan 13 </a>
                    </li>					
                    <li  >
                        <a  href="form.html"><i class="fa fa-edit fa-3x"></i> Pertemuan 14 </a>
                    </li>					
                    <li  >
                        <a  href="form.html"><i class="fa fa-edit fa-3x"></i> UAS </a>
                    </li>
                </ul>
               
            </div>
            
        </nav>  

