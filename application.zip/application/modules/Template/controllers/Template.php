<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Template extends MX_Controller {

        public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
                $this->murl = '/modules/'.$this->uri->segment(1).'/';
        }

	public function header1($url)
	{
            $data['url'] = $url; 
            $this->load->view('header1');
            $this->load->view('menu', $data);
	}
        
        
        public function test(){
            //$this->load->view('blank');
            //$this->load->view('chart');
            //$this->load->view('form');
            //$this->load->view('table');
            //$this->load->view('table-panel');
            $this->load->view('ui');
        }
        
}
